# num = 20
# for i in range(num):
#     if i %2 == 0:
#         print(i)

# num = 40
# for i in range(num):
#     if i %2 == 0:
#         print(i)

# num = 60
# for i in range(num):
#     if i %2 == 0:
#         print(i)


# x = 2 ----> x ^2 + x + 2 8 
# x = 3 ----> x ^2 + x + 2 13 
# f(x) = x ^2 + x + 2  --> f(2) --> 8
# f(x) = x ^2 + x + 2  --> f(3) --> 13

# f(x) = x ^2 + x + 2 --> functin defintaion
# f(3)
# 3 ^ 2 + 3 + 2
# 13

def my_func(num):  # function defination and num is a parameter
    print('.............im from function .............')
    for i in range(num):
        if i %2 == 0:
            print(i)

# num = 20 
# my_func(num)   # calling a funciton
# num = 40 
# my_func(40)
# num = 60
# my_func(60)


print('...........is function called...................')
num = 20 
my_func(num)  # function calling

# DRY ---> Do not repeat yourself
# 0 to 20 
# and 0 to 40 
'''
A function is a block of organized, reusable code that is used to perform a single,
related action. Functions provide better modularity for your application and code reusing.

 or
A function is a block of code which only runs when it is called.
You can pass data, known as parameters, into a function.
A function can return data as a result.
# data strcutures
# loops
# conditinal statements

# sum of 2 numbers
-------------------
STATE    ==> 1 
BEHAVIOR ==> 2,3

       # 1. Customer input
num1 = int(input("Enter number 1 :"))
num2 = int(input("Enter number 2 :"))

       # 2. Business Logic
result = num1 + num2
       # 3. Give response to user
print("Addition is : ",result)

# FUNCTIONS

Advantages: - Avoids code duplication ==> Code reusability
            - When enhancements are required, 
                        we need to change code only one place 

# Functions:
----------------
f(x) = 2x2+3x+1. Find the value of f(x) when x is 10
f(10) = 2(10*10)+3(10)+1
      = 2(100)+30+1
	  = 200+30+1
f(10) = 231

Find the behavior  of f(x) when x value ranges from -2 to 2
f(-2) = 2(-2*-2)+3(-2)+1  = 3
f(-1) = 2(-1*-1)+3(-1)+1  = 0
f(0)  = 2(0*0)+3(0)+1  	  =	1
f(1)  = 2(1*1)+3(1)+1     = 6
f(2)  = 2(2*2)+3(2)+1     =15

f(x)   = 2x2+3x+1  # Function definition
f(2)               # Function calling by passing value
2(2*2)+3(2)+1      # Function execution
15                 # Function end result 
'''

# REQ: Find sum of 2 numbers
    # I. STATE
num1 = int(input("Enter number 1 :"))   # 1. Customer input
num2 = int(input("Enter number 2 :"))

    # II. BEHAVIOR
result = num1 + num2             # 2. Business Logic
print("Addition is : ", result)  # 3. Give response to user

# Problem with above code
'''
Code duplication == we should achieve ==> Code reusability
'''

def sum(num1, num2):
    sum = num1 + num2
    # print(sum)   # will execute only within function
    return sum # return will return to wherever we are calling


result = sum(10,20)
out = result * 30
print(out)
print(sum(10,34))



def sum2(num1, num2):
    sum = num1 + num2
    print('from function',sum)   # will execute only within function
    
result = sum2(10,20)
print('printing result',result)

def my_func2():
    print('hello harsha')

my_func2()


# we can define a funciton without parameters
# we can define a function with parameters
# we can define a function without return 
# we can define a function with return 


# print odd numbers from 0 to num 

for i in range(100):
    if i %2 != 0:
        print(i)



def print_odds(num):  # defining a function without return statement
    for i in range(num):
        if i % 2 != 0:
            print(i)

print_odds(100)
