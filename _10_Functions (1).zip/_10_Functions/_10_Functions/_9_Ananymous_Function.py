
# REQ: Find square of given value

# 1mark : Find square of given value 5
print("Square of value : ", 5*5)
# 2 mark : Find square of given value 5
val = 5
print("Square of value : ", val*val)

# 5 marks : Find square of given value 5
val = int(input("Enter value : "))

def find_square(in_no):
    res = in_no * in_no
    return res

sq_val = find_square(val)
print("Square of value : ", sq_val)

# filter(func,iterable) iterable --> list tuple string set dict 
# Use lambda functions  ==> map filter reduce
# https://www.geeksforgeeks.org/python-lambda-anonymous-functions-filter-map-reduce/
# lambda is an anonymous function, it can have only one expression but many arguments 
sq_val = lambda num : num * num
print(sq_val)

print("Lambda  : Square of value : ", sq_val(5))

# Covert to function
def sq_val(num):
    return num*num

print("Function : Square of value : ", sq_val(5))


# scope of variable
x = 100
print("Value of x :", x)
def get_data():
    # print("Value of x :", x)
    x = 25
    print("Value of x :", x)
get_data()
print("Value of x :", x)

# Function memory allocation
x = 10
print("x details : ", x, id(x))

def get_data():
    print("Welocome to my method")
    return "Hello World"

res = get_data()   # Function calling
print("Result is : ", res)

print("Function details ", get_data)  # Get function body address

def my_func(num):
    pass
num = 10  # data types are immutable
string1 = 'harsha'
my_func(string1)

# Mutable,Immutable :: Pass by value ,Pass by reference
# Pass by value refers to a mechanism of copying the function parameter value to another variable
# while the pass by reference refers to a mechanism of passing the actual parameters to the function.

# The main difference between pass by value and pass by reference is that,
# in a pass by value, the parameter value copies to another variable
# while, in a pass by reference, the actual parameter passes to the function.

# immutable pass by reference
n1 = 10
n1 = 20
num1 = 10
def my_func(number):
    print('number is', number)
    number = 20
    print('number after assigning',number)

my_func(num1)
print('outside of function',num1)


# mutable pass by value
l1 = [1,2,3,4]
l2 = l1
l2.append(3)
print('both l1 and l2',l1,l2)
lst1 = [1,2,3,4]

def my_func2(lst):
    lst.append(3)
    print('list in the function',lst)

print('before calling a function',lst1)
my_func2(lst1)
print('after calling a function',lst1)







lst1 = [x for x in range(10)]
print(lst1)
square = list(map(lambda x: x**2, lst1))
print(square)

# 0 0 1 1 2 4 3 9 

lst1 = [x for x in range(10)]
evens = tuple(filter(lambda x: x %2 == 0 ,lst1))
print('using filter function',evens)

evens_loop = []
for each in lst1:
    if each %2 == 0:
        evens_loop.append(each)

print('using normal loop',evens_loop)
