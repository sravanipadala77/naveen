''''''
'''
# Types 
1. Builtin/ Predefined    : print() id() type()   int float str list tuple dict set
2. User defined Functions : Programmer defined functions 
'''
x = 10
'''
x  <==> variable 
10 <==> value
=  <==> Assignment operator 
'''
print("Value of x : ", x)
'''
Defining a Function: 

* You can define functions to provide the required functionality. Here are simple rules to define a function in Python.
* Function blocks begin with the keyword def followed by the function name and parentheses ( ).
* Any input parameters or arguments should be placed within these parentheses. You can also define parameters 
inside these parentheses.
* The first statement of a function can be an optional statement - the documentation string of the function or docstring.
* The code block within every function starts with a colon (:) and is indented.
* The statement return [expression] exits a function, optionally passing back an expression to the caller. 
A return statement with no arguments is the same as return None.
n1 = 100
n2 =200

Function definition syntax :    def <func_name> () :    # f(var)
                                  # def sum(n1, n2):    # f(x)   

n1,n2 are arguments not variables
'''

# Requirement : Sum of 2 given numbers

# A. With out functions
        # I. STATE
num1 = 10
num2 = 20
        # II. BEHAVIOR
result = num1 + num2
print("Addition is : ", result)


print("-----------Using functions--------")
# B. With Functions
        # I. STATE
num1 = 10
num2 = 20
        # II. BEHAVIOR

# Function definition
def sum(n1, n2):       # function signature
    # n1 = 1000 n2 = 2000
    result = n1 + n2  #3000  # function body
    print("Addition is : ", result)  # we dont have a return statement but if we dont have return statemnet it will return none

# Function calling/invocation
sum(num1, num2)
sum(100, 200)

output = sum(1000,2000)
print(output)

print('...........................after function without calling')
'''
Calling a Function
* Defining a function only gives it a name, specifies the parameters that are to be included in the function 
and structures the blocks of code.
* Once the basic structure of a function is finalized, you can execute it by calling it from another function 
or directly from the Python prompt. 


from _07_DecisionMaking._2_if_else._2_Conditions import get_st_result

marks = 44
res = get_st_result(marks)
print("Student result : ", res)
'''
'''
1. Function definition:
                                def sum(n1, n2):
                                    result = n1 + n2 
                                    print("Addition is : ", result)

    -   Function signature:
                                def sum(n1, n2):

    -  Function body/implementation
                                result = n1 + n2 
                                print("Addition is : ", result)
'''

# from _07_core_python.python_notes._10_Functions._10_Functions._1_basics import sum

# print("addition: ", sum(23,34))

# user defined function
def sum_two(a,b): # function defining without return 
        result = a + b
        print(' sum of two numbers is ',result)

sum_two(100,200)  # function calling

def sum_two(a,b):
        result = a + b
        return result 

print('sum of two numbers with return is ',sum_two(10,200))


"""
Reading a note from paper --> Hello world 
harsha --> reading  def sum():  # function defining
                        print('Hello world')  # functionality 

Madhu --> calling   sum()  # function calling

harsha ---> harsha is returning the notes to madhu to read
                        def sum():  # function defining
                                return 'Hello World'  # returning functionality

Madhu --> calling --> madhu has to read
                        print(sum())





"""