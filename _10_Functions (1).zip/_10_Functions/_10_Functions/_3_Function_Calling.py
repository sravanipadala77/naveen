
# REQ : Find sum of 2 given numbers

    # 1. STATE
'''
num1 = int(input("Enter number1 :"))
num2 = int(input("Enter number2 :"))
'''
num1 = 10
num2 = 200

   # 2. BEHAVIOR
def sum(n1, n2):  # Function definition
    result = n1 + n2
    print("Addition : ", result)

sum(num1, num2)  # Function calling
sum(10, 20)
sum(5+5, 10+10)  # ==> sum(10, 20)

x = 10
x = 10+20+30
'''

9,10 lines : num1,num2  ==> Variables     : 10,20      ==> values
13         : n1,n2      ==> Parameters
17,18,19 :              ==> arguments     
    
'''


